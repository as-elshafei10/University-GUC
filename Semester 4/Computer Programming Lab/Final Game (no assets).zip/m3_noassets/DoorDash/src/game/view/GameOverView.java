package game.view;

import game.engine.Role;
import game.engine.monsters.Monster;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.TextAlignment;

public class GameOverView {

    private static final int WIDTH = 1280;
    private static final int HEIGHT = 720;

    private Pane root;
    private Button returnButton;
    private Button tryAgainButton;

    public GameOverView(Monster winner, Monster player, Monster opponent) {
        root = new Pane();
        root.setPrefSize(WIDTH, HEIGHT);

        Image backgroundImage = GuiStyle.loadAssetImage(getClass(), "menu.png");
        if (backgroundImage != null) {
            ImageView background = new ImageView(backgroundImage);
            background.setFitWidth(WIDTH);
            background.setFitHeight(HEIGHT);
            background.setPreserveRatio(false);
            root.getChildren().add(background);
        }

        Rectangle dim = new Rectangle(WIDTH, HEIGHT);
        dim.setFill(Color.web("rgba(0,0,0,0.52)"));
        root.getChildren().add(dim);

        boolean playerWon = winner != null && winner == player;
        createResultCard(winner, player, opponent, playerWon);
    }

    private void createResultCard(Monster winner, Monster player, Monster opponent, boolean playerWon) {
        final double panelW = 560;
        final double panelH = playerWon ? 551 : 557;
        final double panelX = (WIDTH - panelW) / 2.0;
        final double panelY = 54;

        Image panelImage = GuiStyle.loadAssetImage(getClass(), playerWon ? "ui/gameover/victory_panel.png" : "ui/gameover/defeat_panel.png");
        if (panelImage != null) {
            ImageView panel = new ImageView(panelImage);
            panel.setFitWidth(panelW);
            panel.setPreserveRatio(true);
            panel.setSmooth(true);
            panel.setLayoutX(panelX);
            panel.setLayoutY(panelY);
            root.getChildren().add(panel);
        }

        Label title = new Label(playerWon ? "VICTORY!" : "GAME OVER");
        title.setAlignment(Pos.CENTER);
        title.setTextAlignment(TextAlignment.CENTER);
        title.setLayoutX(panelX + 60);
        title.setLayoutY(panelY + 46);
        title.setPrefWidth(panelW - 120);
        title.setPrefHeight(54);
        title.setStyle(GuiStyle.titleText(38));
        root.getChildren().add(title);

        Image winnerImage = choosePortrait(winner);
        if (winnerImage != null) {
            ImageView winnerPortrait = new ImageView(winnerImage);
            winnerPortrait.setFitWidth(225);
            winnerPortrait.setFitHeight(225);
            winnerPortrait.setPreserveRatio(true);
            winnerPortrait.setSmooth(true);
            winnerPortrait.setCache(true);
            // Centered in the circular slot and lowered slightly so it does not touch the title.
            winnerPortrait.setLayoutX(panelX + (panelW - 225) / 2.0);
            winnerPortrait.setLayoutY(panelY + 118);
            winnerPortrait.setStyle("-fx-effect: dropshadow(gaussian, rgba(35,247,255,0.75), 18, 0.32, 0, 0);");
            root.getChildren().add(winnerPortrait);
        }

        Label winnerLabel = new Label(formatWinnerLine(winner));
        winnerLabel.setAlignment(Pos.CENTER);
        winnerLabel.setTextAlignment(TextAlignment.CENTER);
        winnerLabel.setWrapText(true);
        winnerLabel.setLayoutX(panelX + 62);
        winnerLabel.setLayoutY(panelY + 335);
        winnerLabel.setPrefWidth(panelW - 124);
        winnerLabel.setPrefHeight(58);
        winnerLabel.setStyle(GuiStyle.normalText(19) +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.96), 5, 0.78, 0, 1);");
        root.getChildren().add(winnerLabel);

        Label finalStats = new Label(formatFinalStats(player, opponent));
        finalStats.setAlignment(Pos.CENTER);
        finalStats.setTextAlignment(TextAlignment.CENTER);
        finalStats.setWrapText(true);
        finalStats.setLayoutX(panelX + 58);
        finalStats.setLayoutY(panelY + 385);
        finalStats.setPrefWidth(panelW - 116);
        finalStats.setPrefHeight(76);
        finalStats.setStyle("-fx-font-size: 14px;" +
                            "-fx-font-family: 'Consolas', 'Arial';" +
                            "-fx-font-weight: bold;" +
                            "-fx-text-fill: white;" +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.96), 4, 0.75, 0, 1);");
        root.getChildren().add(finalStats);

        returnButton = new Button("RETURN TO LOBBY");
        returnButton.setLayoutX(panelX + (panelW - 374) / 2.0);
        returnButton.setLayoutY(panelY + 497);
        returnButton.setPrefWidth(170);
        returnButton.setPrefHeight(40);
        returnButton.setAlignment(Pos.CENTER);
        returnButton.setStyle(GuiStyle.glowButton(playerWon ? "cyan" : "orange", false));
        GuiStyle.applyGlowHover(returnButton,
                GuiStyle.glowButton(playerWon ? "cyan" : "orange", false),
                GuiStyle.glowButton(playerWon ? "cyan" : "orange", true));
        root.getChildren().add(returnButton);
        returnButton.toFront();
        
        tryAgainButton = new Button("TRY AGAIN");

        tryAgainButton.setLayoutX(panelX + (panelW + 34) / 2.0);
        tryAgainButton.setLayoutY(returnButton.getLayoutY());
        tryAgainButton.setPrefWidth(returnButton.getPrefWidth());
        tryAgainButton.setPrefHeight(returnButton.getPrefHeight());

        tryAgainButton.setAlignment(Pos.CENTER);
        tryAgainButton.setStyle(GuiStyle.glowButton(playerWon ? "cyan" : "orange", false));

        GuiStyle.applyGlowHover(
        		tryAgainButton,
        		GuiStyle.glowButton(playerWon ? "cyan" : "orange", false),
        		GuiStyle.glowButton(playerWon ? "cyan" : "orange", true)
     );

     root.getChildren().add(tryAgainButton);
     tryAgainButton.toFront();
    }

    private Image choosePortrait(Monster monster) {
        if (monster == null) return null;
        if (monster.getOriginalRole() == Role.SCARER) {
            return GuiStyle.loadAssetImage(getClass(), "ui/portraits/scarer_avatar.png");
        }
        return GuiStyle.loadAssetImage(getClass(), "ui/portraits/laugher_avatar.png");
    }

    private String formatWinnerLine(Monster winner) {
        if (winner == null) return "Winner unavailable";
        return winner.getName() + " wins as " + winner.getRole() + "\nType: " + winner.getClass().getSimpleName();
    }

    private String formatFinalStats(Monster player, Monster opponent) {
        String p = player == null ? "Player: -" : "Player: " + player.getName() + " | " + player.getEnergy() + " energy | Cell " + player.getPosition();
        String o = opponent == null ? "Opponent: -" : "Opponent: " + opponent.getName() + " | " + opponent.getEnergy() + " energy | Cell " + opponent.getPosition();
        return "FINAL RESULTS\n" + p + "\n" + o;
    }

    public Pane getRoot() {
        return root;
    }

    public Button getReturnButton() {
        return returnButton;
    }
    
    public Button getTryAgainButton() {
        return tryAgainButton;
    }
}
