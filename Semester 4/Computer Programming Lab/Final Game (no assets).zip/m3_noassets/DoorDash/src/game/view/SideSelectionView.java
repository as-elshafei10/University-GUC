package game.view;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class SideSelectionView {

    private Pane root;
    private Button scarerButton;
    private Button laugherButton;
    private Button muteButton;

    public SideSelectionView() {
        root = new Pane();
        root.setPrefSize(1280, 720);

        Image backgroundImage = GuiStyle.loadAssetImage(getClass(), "SideSelection.png");
        if (backgroundImage != null) {
            ImageView background = new ImageView(backgroundImage);
            background.setFitWidth(1280);
            background.setFitHeight(720);
            background.setPreserveRatio(false);
            root.getChildren().add(background);
        }

        createTeamPortraits();
        createConfirmButtons();
        createMuteButton();
    }

    private void createTeamPortraits() {
        Image scarer = GuiStyle.loadAssetImage(getClass(), "ui/portraits/scarer_avatar.png");
        Image laugher = GuiStyle.loadAssetImage(getClass(), "ui/portraits/laugher_avatar.png");

        // Fall back to older clean monsters if the avatar assets are not copied yet.
        if (scarer == null) scarer = GuiStyle.loadAssetImage(getClass(), "monsters/small/scarer_monster.png");
        if (laugher == null) laugher = GuiStyle.loadAssetImage(getClass(), "monsters/small/laugher_monster.png");

        if (scarer != null) {
            ImageView scarerView = createPortraitView(scarer, 145, 478, 292);
            scarerView.setStyle("-fx-effect: dropshadow(gaussian, rgba(188,54,255,0.86), 18, 0.34, 0, 0);");
            root.getChildren().add(scarerView);
        }

        if (laugher != null) {
            ImageView laugherView = createPortraitView(laugher, 145, 662, 292);
            laugherView.setStyle("-fx-effect: dropshadow(gaussian, rgba(72,255,74,0.80), 18, 0.30, 0, 0);");
            root.getChildren().add(laugherView);
        }
    }

    private ImageView createPortraitView(Image image, double size, double x, double y) {
        ImageView view = new ImageView(image);
        view.setFitWidth(size);
        view.setFitHeight(size);
        view.setPreserveRatio(true);
        view.setSmooth(true);
        view.setCache(true);
        view.setLayoutX(x);
        view.setLayoutY(y);
        view.setMouseTransparent(true);
        return view;
    }

    private void createConfirmButtons() {
        scarerButton = new Button();
        scarerButton.setLayoutX(512);
        scarerButton.setLayoutY(516);
        scarerButton.setPrefWidth(128);
        scarerButton.setPrefHeight(78);
        scarerButton.setStyle(GuiStyle.transparentButton());
        GuiStyle.applyTransparentHover(scarerButton);

        laugherButton = new Button();
        laugherButton.setLayoutX(652);
        laugherButton.setLayoutY(516);
        laugherButton.setPrefWidth(128);
        laugherButton.setPrefHeight(78);
        laugherButton.setStyle(GuiStyle.transparentButton());
        GuiStyle.applyTransparentHover(laugherButton);

        root.getChildren().addAll(scarerButton, laugherButton);
        scarerButton.toFront();
        laugherButton.toFront();
    }

    private void createMuteButton() {
        muteButton = new Button();
        muteButton.setLayoutX(1164);
        muteButton.setLayoutY(38);
        muteButton.setPrefWidth(92);
        muteButton.setPrefHeight(92);
        muteButton.setFocusTraversable(false);
        muteButton.setStyle(GuiStyle.muteButton(false));
        root.getChildren().add(muteButton);
        muteButton.toFront();
    }

    public Pane getRoot() {
        return root;
    }

    public Button getScarerButton() {
        return scarerButton;
    }

    public Button getLaugherButton() {
        return laugherButton;
    }

    public Button getMuteButton() {
        return muteButton;
    }
}
