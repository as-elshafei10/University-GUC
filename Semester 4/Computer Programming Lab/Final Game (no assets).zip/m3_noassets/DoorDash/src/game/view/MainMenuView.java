package game.view;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class MainMenuView {

    private Pane root;
    private Button playButton;
    private Button quitButton;
    private Button muteButton;

    public MainMenuView() {
        root = new Pane();
        root.setPrefSize(1280, 720);

        Image backgroundImage = GuiStyle.loadAssetImage(getClass(), "menu.png");
        if (backgroundImage != null) {
            ImageView background = new ImageView(backgroundImage);
            background.setFitWidth(1280);
            background.setFitHeight(720);
            background.setPreserveRatio(false);
            root.getChildren().add(background);
        }

        createButtons();
        createMuteButton();
    }

    private void createButtons() {
        // Exact invisible hitbox on the PLAY GAME button only.
        playButton = new Button();
        playButton.setLayoutX(512);
        playButton.setLayoutY(304);
        playButton.setPrefWidth(278);
        playButton.setPrefHeight(88);
        playButton.setStyle(GuiStyle.transparentButton());
        GuiStyle.applyTransparentHover(playButton);

        // Exact invisible hitbox on the QUIT GAME button only.
        quitButton = new Button();
        quitButton.setLayoutX(512);
        quitButton.setLayoutY(424);
        quitButton.setPrefWidth(278);
        quitButton.setPrefHeight(90);
        quitButton.setStyle(GuiStyle.transparentButton());
        GuiStyle.applyTransparentHover(quitButton);

        root.getChildren().addAll(playButton, quitButton);
    }


    private void createMuteButton() {
        muteButton = new Button();
        // Exact hitbox on the round MUTE button at the top-right.
        muteButton.setLayoutX(1164);
        muteButton.setLayoutY(38);
        muteButton.setPrefWidth(92);
        muteButton.setPrefHeight(92);
        muteButton.setFocusTraversable(false);
        muteButton.setStyle(GuiStyle.muteButton(false));
        root.getChildren().add(muteButton);
        muteButton.toFront();
    }

    public Pane getRoot() {
        return root;
    }

    public Button getPlayButton() {
        return playButton;
    }

    public Button getQuitButton() {
        return quitButton;
    }
    public Button getMuteButton() {
        return muteButton;
    }
}
