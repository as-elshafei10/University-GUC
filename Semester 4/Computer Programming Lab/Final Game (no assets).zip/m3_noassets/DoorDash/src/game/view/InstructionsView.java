package game.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.TextAlignment;

public class InstructionsView {

    private Pane root;
    private Button continueButton;
    private Button muteButton;

    public InstructionsView() {
        root = new Pane();
        root.setPrefSize(1280, 720);

        Image backgroundImage = GuiStyle.loadAssetImage(getClass(), "Instructions.png");
        if (backgroundImage != null) {
            ImageView background = new ImageView(backgroundImage);
            background.setFitWidth(1280);
            background.setFitHeight(720);
            background.setPreserveRatio(false);
            root.getChildren().add(background);
        }

        createInstructionsText();
        createContinueButton();
        createMuteButton();
    }

    private void createInstructionsText() {
        Label instructionsText = new Label(
            "WELCOME TO DOOR DASH!\n\n" +
            "Your mission is to race across the monster\n" +
            "factory board and reach the final door.\n\n" +
            "HOW TO PLAY:\n" +
            "1. Choose your team: SCARER or LAUGHER.\n" +
            "2. Roll the dice to move your monster\n" +
            "   across the board.\n" +
            "3. Land on doors to gain or lose\n" +
            "   canister energy.\n" +
            "4. Card cells trigger special cards.\n" +
            "5. Monster cells may activate powerups\n" +
            "   or cause energy battles.\n" +
            "6. Conveyor belts push you forward.\n" +
            "7. Contamination socks drag you backward\n" +
            "   and reduce your energy.\n\n" +
            "POWERUPS:\n" +
            "Activate your monster's powerup before\n" +
            "rolling if you have enough energy.\n\n" +
            "STATUS EFFECTS:\n" +
            "Shield blocks negative energy effects.\n" +
            "Freeze skips a turn. Confusion swaps roles.\n\n" +
            "WIN CONDITION:\n" +
            "Reach cell 99 with at least 1000 energy.\n\n" +
            "DEMO KEYS:\n" +
            "E adds energy. W sends the player to 99."
        );

        instructionsText.setWrapText(true);
        instructionsText.setAlignment(Pos.TOP_CENTER);
        instructionsText.setTextAlignment(TextAlignment.CENTER);
        instructionsText.setMaxWidth(332);
        instructionsText.setPrefWidth(332);
        instructionsText.setPadding(new Insets(8, 12, 8, 12));
        instructionsText.setStyle(
            "-fx-font-size: 12px;" +
            "-fx-font-family: 'Consolas', 'Arial';" +
            "-fx-font-weight: bold;" +
            "-fx-text-fill: white;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.95), 4, 0.78, 0, 1);"
        );

        StackPane textHolder = new StackPane(instructionsText);
        textHolder.setAlignment(Pos.TOP_CENTER);
        textHolder.setPadding(new Insets(0));
        textHolder.setStyle("-fx-background-color: transparent;");
        textHolder.setPrefWidth(348);
        textHolder.setMinWidth(348);

        ScrollPane scroll = new ScrollPane(textHolder);
        // Precisely centered inside the glowing blue monitor area.
        // Coordinates matched to the inner glowing blue monitor area.
        // The text is centered inside the screen, not sitting on top of the title art.
        scroll.setLayoutX(452);
        scroll.setLayoutY(273);
        scroll.setPrefWidth(352);
        scroll.setPrefHeight(140);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scroll.setPannable(true);
        scroll.setFocusTraversable(false);
        scroll.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-background: transparent;" +
            "-fx-control-inner-background: transparent;" +
            "-fx-border-color: transparent;" +
            "-fx-padding: 0;"
        );

        root.getChildren().add(scroll);
    }

    private void createContinueButton() {
        continueButton = new Button();
        continueButton.setLayoutX(508);
        continueButton.setLayoutY(520);
        continueButton.setPrefWidth(282);
        continueButton.setPrefHeight(76);
        continueButton.setStyle(GuiStyle.transparentButton());
        GuiStyle.applyTransparentHover(continueButton);
        root.getChildren().add(continueButton);
        continueButton.toFront();
    }

    private void createMuteButton() {
        muteButton = new Button();
        muteButton.setLayoutX(1164);
        muteButton.setLayoutY(38);
        muteButton.setPrefWidth(92);
        muteButton.setPrefHeight(92);
        muteButton.setFocusTraversable(false);
        muteButton.setStyle(GuiStyle.muteButton(false));
        root.getChildren().add(muteButton);
        muteButton.toFront();
    }

    public Pane getRoot() {
        return root;
    }

    public Button getContinueButton() {
        return continueButton;
    }

    public Button getMuteButton() {
        return muteButton;
    }
}
