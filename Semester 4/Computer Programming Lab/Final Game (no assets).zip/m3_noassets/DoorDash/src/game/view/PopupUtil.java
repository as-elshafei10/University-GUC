package game.view;

import game.view.audio.AudioManager;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public final class PopupUtil {

    private PopupUtil() { }

    public static void showMessage(Stage owner, String title, String message) {
        show(owner, title, message, false);
    }

    public static void showError(Stage owner, String title, String message) {
        show(owner, title, message, true);
    }

    private static void show(Stage owner, String title, String message, boolean error) {
        if (error) {
            playErrorSafe();
        }
        Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        if (owner != null) {
            popup.initOwner(owner);
        }
        popup.setResizable(false);
        popup.setTitle(title);

        Label titleLabel = new Label(title);
        titleLabel.setStyle(GuiStyle.titleText(20));

        Label messageLabel = new Label(message);
        messageLabel.setWrapText(true);
        messageLabel.setMaxWidth(420);
        messageLabel.setAlignment(Pos.CENTER);
        messageLabel.setStyle(GuiStyle.normalText(14));

        Button okButton = new Button("OK");
        okButton.setPrefWidth(130);
        okButton.setPrefHeight(38);
        okButton.setStyle(error ? GuiStyle.button("#ff6969", "#7a1111")
                                : GuiStyle.button("#23f7ff", "#086b85"));
        GuiStyle.applyHover(okButton);
        okButton.setOnAction(e -> {
            playClickSafe();
            popup.close();
        });

        VBox root = new VBox(16);
        root.setAlignment(Pos.CENTER);
        root.setPrefSize(470, 230);
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #07101f, #160b2d);" +
                      "-fx-padding: 22;" +
                      "-fx-border-color: " + (error ? "#ff4d4d" : "#23f7ff") + ";" +
                      "-fx-border-width: 3;" +
                      "-fx-effect: dropshadow(gaussian, black, 25, 0.45, 0, 0);");

        root.getChildren().addAll(titleLabel, messageLabel, okButton);
        popup.setScene(new Scene(root));
        popup.showAndWait();
    }
    private static void playErrorSafe() {
        try { AudioManager.playError(); } catch (Throwable ignored) { }
    }

    private static void playClickSafe() {
        try { AudioManager.playClick(); } catch (Throwable ignored) { }
    }

}
