package game.engine.cells;

import game.engine.monsters.*;

public class MonsterCell extends Cell {
	private Monster cellMonster;

	public MonsterCell(String name, Monster cellMonster) {
		super(name);
		this.cellMonster = cellMonster;
	}

	public Monster getCellMonster() {
		return cellMonster;
	}
	@Override
	public void onLand(Monster landingMonster, Monster opponentMonster) {
	    super.onLand(landingMonster, opponentMonster);
	    if (cellMonster.getRole() == landingMonster.getRole()) {
	        landingMonster.executePowerupEffect(opponentMonster);
	        return;
	    }
	    if (landingMonster.getEnergy() > cellMonster.getEnergy()) {
	        int landingEnergy = landingMonster.getEnergy();
	        int cellEnergy = cellMonster.getEnergy();
	        if (landingMonster.isShielded()) {
	            landingMonster.setShielded(false);
	            cellMonster.setEnergy(landingEnergy);

	        } else {
	            landingMonster.setEnergy(cellEnergy);
	            cellMonster.setEnergy(landingEnergy);
	        }
	    }
	}

}
