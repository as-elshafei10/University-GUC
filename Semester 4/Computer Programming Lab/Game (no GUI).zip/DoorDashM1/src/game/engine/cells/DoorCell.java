package game.engine.cells;

import game.engine.Board;
import game.engine.Role;
import game.engine.interfaces.CanisterModifier;
import game.engine.monsters.Monster;

public class DoorCell extends Cell implements CanisterModifier {
	private Role role;
	private int energy;
	private boolean activated;

	public DoorCell(String name, Role role, int energy) {
		super(name);
		this.role = role;
		this.energy = energy;
		this.activated = false;
	}

	public Role getRole() {
		return role;
	}

	public int getEnergy() {
		return energy;
	}

	public boolean isActivated() {
		return activated;
	}

	public void setActivated(boolean isActivated) {
		this.activated = isActivated;
	}

	@Override
	public void modifyCanisterEnergy(Monster monster, int canisterValue) {
		int effectiveValue = (monster.getRole() == role) ? canisterValue : -canisterValue;
		monster.alterEnergy(effectiveValue);
	}

	@Override
	public void onLand(Monster landingMonster, Monster opponentMonster) {
		super.onLand(landingMonster, opponentMonster);
		if (!activated) {
			int canisterValue = energy;

			if (landingMonster.getRole() != role && landingMonster.isShielded()) {
				landingMonster.setShielded(false);
			} else {
				landingMonster.alterEnergy(landingMonster.getRole() == role ? canisterValue : -canisterValue);
				for (Monster stationed : Board.getStationedMonsters()) {
					if (stationed.getRole() == landingMonster.getRole()) {
						modifyCanisterEnergy(stationed, canisterValue);
					}
				}
				activated = true;
			}
		}
	}
}