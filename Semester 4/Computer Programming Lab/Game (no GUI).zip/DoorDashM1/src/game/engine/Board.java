package game.engine;

import java.util.ArrayList;
import java.util.Collections;

import game.engine.cards.Card;
import game.engine.cells.*;
import game.engine.exceptions.InvalidMoveException;
import game.engine.monsters.Monster;

public class Board {
	private Cell[][] boardCells;
	private static ArrayList<Monster> stationedMonsters;
	private static ArrayList<Card> originalCards;
	public static ArrayList<Card> cards;

	public Board(ArrayList<Card> readCards) {
		this.boardCells = new Cell[Constants.BOARD_ROWS][Constants.BOARD_COLS];
		stationedMonsters = new ArrayList<Monster>();
		originalCards = readCards;
		cards = new ArrayList<Card>();
		setCardsByRarity();
	}

	public Cell[][] getBoardCells() {
		return boardCells;
	}

	public static ArrayList<Monster> getStationedMonsters() {
		return stationedMonsters;
	}

	public static void setStationedMonsters(ArrayList<Monster> stationedMonsters) {
		Board.stationedMonsters = stationedMonsters;
	}

	public static ArrayList<Card> getOriginalCards() {
		return originalCards;
	}

	public static ArrayList<Card> getCards() {
		return cards;
	}

	public static void setCards(ArrayList<Card> cards) {
		Board.cards = cards;
	}

	private int[] indexToRowCol(int index) {
		int row = index / Constants.BOARD_COLS;
		int col;
		if (row % 2 == 0) {
			col = index % Constants.BOARD_COLS;
		} else {
			col = Constants.BOARD_COLS - 1 - (index % Constants.BOARD_COLS);
		}
		return new int[]{row, col};
	}

	private Cell getCell(int index) {
		int[] rowCol = indexToRowCol(index);
		return boardCells[rowCol[0]][rowCol[1]];
	}

	private void setCell(int index, Cell cell) {
		int[] rowCol = indexToRowCol(index);
		boardCells[rowCol[0]][rowCol[1]] = cell;
	}

	public void initializeBoard(ArrayList<Cell> specialCells) {
		ArrayList<Cell> doorCells = new ArrayList<Cell>();
		ArrayList<Cell> conveyorCells = new ArrayList<Cell>();
		ArrayList<Cell> sockCells = new ArrayList<Cell>();

		for (Cell c : specialCells) {
			if (c instanceof DoorCell) doorCells.add(c);
			else if (c instanceof ConveyorBelt) conveyorCells.add(c);
			else if (c instanceof ContaminationSock) sockCells.add(c);
		}

		int doorIndex = 0;
		for (int i = 0; i < Constants.BOARD_SIZE; i++) {
			if (i % 2 == 0) {
				setCell(i, new Cell("Rest Cell"));
			} else {
				if (doorIndex < doorCells.size()) {
					setCell(i, doorCells.get(doorIndex++));
				}
			}
		}

		for (int idx : Constants.CARD_CELL_INDICES) {
			setCell(idx, new CardCell("Card Cell"));
		}

		for (int i = 0; i < Constants.CONVEYOR_CELL_INDICES.length && i < conveyorCells.size(); i++) {
			setCell(Constants.CONVEYOR_CELL_INDICES[i], conveyorCells.get(i));
		}

		for (int i = 0; i < Constants.SOCK_CELL_INDICES.length && i < sockCells.size(); i++) {
			setCell(Constants.SOCK_CELL_INDICES[i], sockCells.get(i));
		}

		for (int i = 0; i < Constants.MONSTER_CELL_INDICES.length && i < stationedMonsters.size(); i++) {
			Monster stationed = stationedMonsters.get(i);
			stationed.setPosition(Constants.MONSTER_CELL_INDICES[i]);
			setCell(Constants.MONSTER_CELL_INDICES[i], new MonsterCell(stationed.getName(), stationed));
		}
	}

	private void setCardsByRarity() {
		ArrayList<Card> expanded = new ArrayList<Card>();
		for (Card card : originalCards) {
			for (int i = 0; i < card.getRarity(); i++) {
				expanded.add(card);
			}
		}
		originalCards = expanded;
		cards = new ArrayList<Card>(originalCards);
		Collections.shuffle(cards);
	}

	public static void reloadCards() {
		cards = new ArrayList<Card>(originalCards);
		Collections.shuffle(cards);
	}

	public static Card drawCard() {
		if (cards.isEmpty()) {
			reloadCards();
		}
		return cards.remove(0);
	}

	public void moveMonster(Monster currentMonster, int roll, Monster opponentMonster)
			throws InvalidMoveException {
		int oldPosition = currentMonster.getPosition();
		currentMonster.move(roll);
		Cell landedCell = getCell(currentMonster.getPosition());
		landedCell.onLand(currentMonster, opponentMonster);

		if (currentMonster.getPosition() == opponentMonster.getPosition()) {
			currentMonster.setPosition(oldPosition);
			updateMonsterPositions(currentMonster, opponentMonster);
			throw new InvalidMoveException();
		}

		if (currentMonster.isConfused() && opponentMonster.isConfused()) {
			currentMonster.decrementConfusion();
			opponentMonster.decrementConfusion();
		}

		updateMonsterPositions(currentMonster, opponentMonster);
	}

	private void updateMonsterPositions(Monster player, Monster opponent) {
		for (int i = 0; i < Constants.BOARD_SIZE; i++) {
			Cell cell = getCell(i);
			if (cell != null && !(cell instanceof MonsterCell)) {
				cell.setMonster(null);
			}
		}
		getCell(player.getPosition()).setMonster(player);
		getCell(opponent.getPosition()).setMonster(opponent);
	}
}