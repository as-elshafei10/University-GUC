package game.engine.monsters;

import game.engine.Role;

public class Dynamo extends Monster {
	private boolean applyPassive = false;

	public Dynamo(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.applyPassive = true;
	}

	@Override
	public void executePowerupEffect(Monster opponentMonster) {
		opponentMonster.setFrozen(true);
	}

	@Override
	public void setEnergy(int energy) {
		if (applyPassive) {
			int change = energy - this.getEnergy();
			super.setEnergy(this.getEnergy() + (change * 2));
		} else {
			super.setEnergy(energy);
		}
	}
}