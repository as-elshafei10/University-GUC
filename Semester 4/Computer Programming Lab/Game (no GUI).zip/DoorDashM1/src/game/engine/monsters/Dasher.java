package game.engine.monsters;

import game.engine.Role;

public class Dasher extends Monster {
	private int momentumTurns;

	public Dasher(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.momentumTurns = 0;
	}
	
	public int getMomentumTurns() {
		return momentumTurns;
	}
	
	public void setMomentumTurns(int momentumTurns) {
		this.momentumTurns = momentumTurns;
	}
	
	@Override
	public void move(int distance) {
	    if (this.isFrozen()) {
	        this.setFrozen(false);
	        return;
	    }
	    int n = 2;
	    if (this.getMomentumTurns() > 0) {
	        n = 3;
	        this.setMomentumTurns(this.getMomentumTurns() - 1);
	    }
	    this.setPosition(this.getPosition() + distance * n);
	}

	@Override
	public void executePowerupEffect(Monster opponentMonster) {
		this.setMomentumTurns(momentumTurns + 3);
		
	}

	
}