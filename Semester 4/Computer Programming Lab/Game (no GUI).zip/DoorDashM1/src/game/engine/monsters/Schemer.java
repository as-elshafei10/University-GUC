package game.engine.monsters;

import java.util.ArrayList;

import game.engine.Role;
import game.engine.Board;
import game.engine.Constants;

public class Schemer extends Monster {
	private boolean applyPassive = false;

	public Schemer(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.applyPassive = true;
	}

	private int stealEnergyFrom(Monster target) {
		int stolen_energy;
		if (target.getEnergy() >= Constants.SCHEMER_STEAL) {
			stolen_energy = Constants.SCHEMER_STEAL;
			target.setEnergy(target.getEnergy() - stolen_energy);
		} else {
			stolen_energy = target.getEnergy();
			target.setEnergy(0);
		}
		return stolen_energy;
	}

	@Override
	public void setEnergy(int energy) {
		if (applyPassive) {
			super.setEnergy(energy + 10);
		} else {
			super.setEnergy(energy);
		}
	}

	@Override
	public void executePowerupEffect(Monster opponentMonster) {
		int stolen_energy = stealEnergyFrom(opponentMonster);
		ArrayList<Monster> stationedMonsters = Board.getStationedMonsters();
		for (int i = 0; i < stationedMonsters.size(); i++) {
			stolen_energy += this.stealEnergyFrom(stationedMonsters.get(i));
		}
		this.setEnergy(this.getEnergy() + stolen_energy);
	}
}