package game.engine.monsters;

import game.engine.Role;

public class MultiTasker extends Monster {
	private int normalSpeedTurns;
	private boolean applyPassive = false;

	public MultiTasker(String name, String description, Role role, int energy) {
		super(name, description, role, energy);
		this.normalSpeedTurns = 0;
		this.applyPassive = true;
	}

	public int getNormalSpeedTurns() {
		return normalSpeedTurns;
	}

	public void setNormalSpeedTurns(int normalSpeedTurns) {
		this.normalSpeedTurns = normalSpeedTurns;
	}

	@Override
	public void executePowerupEffect(Monster opponentMonster) {
		this.setNormalSpeedTurns(normalSpeedTurns + 2);
	}

	@Override
	public void setEnergy(int energy) {
		if (applyPassive) {
			super.setEnergy(energy + 200);
		} else {
			super.setEnergy(energy);
		}
	}

	@Override
	public void move(int distance) {
		if (this.isFrozen()) {
			this.setFrozen(false);
			return;
		}
		if (normalSpeedTurns == 0) {
			this.setPosition(this.getPosition() + distance / 2);
		} else {
			this.setPosition(this.getPosition() + distance);
			normalSpeedTurns--;
		}
	}
}