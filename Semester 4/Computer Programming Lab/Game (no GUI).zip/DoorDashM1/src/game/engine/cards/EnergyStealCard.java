package game.engine.cards;

import game.engine.interfaces.CanisterModifier;
import game.engine.monsters.Monster;

public class EnergyStealCard extends Card implements CanisterModifier {
	private int energy;

	public EnergyStealCard(String name, String description, int rarity, int energy) {
		super(name, description, rarity, true);
		this.energy = energy;
	}

	public int getEnergy() {
		return energy;
	}

	@Override
	public void modifyCanisterEnergy(Monster monster, int canisterValue) {
		monster.alterEnergy(canisterValue);
	}

	@Override
	public void performAction(Monster player, Monster opponent) {
		int stolen_energy;
		if (opponent.getEnergy() >= energy) {
			stolen_energy = energy;
		} else {
			stolen_energy = opponent.getEnergy();
		}
		if (opponent.isShielded()) {
			opponent.setShielded(false);
		} else {
			opponent.alterEnergy(-stolen_energy);
			player.alterEnergy(stolen_energy);
		}
	}
}